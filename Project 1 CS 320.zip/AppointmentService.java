package cs320_module5_appointmentservice;

import java.util.*;

public class AppointmentService {

final private List<Appointment> listOfAppointment = new ArrayList<>();


 private String newUniqueId() {

 return UUID.randomUUID().toString().substring(
 0, Math.min(toString().length(), 10));
 }

 public void addAppointment(Date date, String description) {
 Appointment appt = new Appointment(newUniqueId(), date, description);
 listOfAppointment.add(appt);
 }

 public void deleteAppointment(String id) throws Exception {
 listOfAppointment.remove(searchForAppointment(id));
 }

 protected List<Appointment> getAppointmentList() { return 
listOfAppointment; }
 private Appointment searchForAppointment(String id) throws Exception {
 int index = 0;

 while (index < listOfAppointment.size()) {
 if (id.equals(listOfAppointment.get(index).getAppointmentID())) {
 return listOfAppointment.get(index);
 }

 index++;

 }

 throw new Exception("The appointment does not exist!");

 }
}
