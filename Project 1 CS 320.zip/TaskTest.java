package cs320_module4_taskService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskTest {
//test getters

 @Test
 void testGetTaskId() {
 Task task = new Task("123456789","checkChance","checking Chance for fleas
and ticks");
 Assertions.assertEquals("123456789", task.getTaskId());
 }

 @Test
 void testGetName() {
 Task task = new Task("123456789","checkChance","checking Chance for fleas
and ticks");
 Assertions.assertEquals("checkChance", task.getName());
 }

 @Test
 void testGetDescription() {
 Task task = new Task("123456789","checkChance","checking Chance for fleas
and ticks");
 Assertions.assertEquals("checking Change for fleas and ticks", 
task.getDescription());
 }

//test setters

 @Test
 void testSetName() {
 Task task = new Task("123456789","checkChance","checking Chance for fleas
and ticks");
 task.setName("checkChance");
 Assertions.assertEquals("checkChance", task.getName());
 }

 @Test
 void testSetDescription() {
 Task task = new Task("123456789","checkChance","checking Chance for fleas
and ticks");
 task.setDescription("checking Chance for fleas and ticks");
 Assertions.assertEquals("checking Chance for fleas and ticks", 
task.getDescription());
 }

//test string length

 @Test
 void testTaskIdTooLong() {
 Assertions.assertThrows(IllegalArgumentException.class,
 () -> new 
Task("123456789","checkChance","checking Chance for fleas and ticks"));
 }

 @Test
 void testSetTooLongName() {

 Task task = new Task("123456789","checkChanceFleasTicksLong","checking 
Chance for fleas and ticks");
 Assertions.assertThrows(IllegalArgumentException.class,
 () -> task.setName("checkChanceFleasTicksLong"));
 }

 @Test
 void testSetTooLongDescription() {
 Task task = new Task("123456789","checkChanceFleasTicksLong","checking 
Chance for fleas and ticks character check 50 characters or more");
 Assertions.assertThrows(IllegalArgumentException.class,
 () -> task.setDescription("checking Chance for 
fleas and ticks character check 50 characters or more"));
 }
//test null

 @Test
 void testTaskIdNull() {
 Assertions.assertThrows(IllegalArgumentException.class,
 () -> new 
Task("123456789","checkChance","checking Chance for fleas and ticks"));
 }

 @Test
 void testTaskNameNull() {
 Task task = new Task("123456789","checkChance","checking Chance for fleas
and ticks");
 Assertions.assertThrows(IllegalArgumentException.class,
 () -> task.setName(null));
 }

 @Test
 void testTaskDescriptionNull() {
 Task task = new Task("123456789","checkChance","checking Chance for fleas
and ticks");
 Assertions.assertThrows(IllegalArgumentException.class,
 () -> task.setDescription(null));

 }

} //end class
