package cs320_module4_taskService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskServiceTest {

//testing addTask
 @Test
 void testAddTask() {
 TaskService service = new TaskService();
 service.addTask("ChanceTask", "check Chance for fleas and ticks");
 Assertions.assertNotNull(service.getlistOfTask().get(0).getTaskId());
 Assertions.assertNotEquals("INITIAL",
 service.getlistOfTask().get(0).getTaskId());
 }

 @Test
 void testAddTaskDescription() {
 TaskService service = new TaskService();
 service.addTask("ChanceTask", "check Chance for fleas and ticks");
 
Assertions.assertNotNull(service.getlistOfTask().get(0).getDescription());
 Assertions.assertEquals("check Chance for fleas and ticks",
 service.getlistOfTask().get(0).getDescription());
 }
//test addTask length

 @Test
 void testAddTaskTooLongName() {
 TaskService service = new TaskService();
 Assertions.assertThrows(IllegalArgumentException.class,
 () -> service.addTask("ChanceTaskOPantssssss", 
"check Chance for fleas and ticks"));

 }

 @Test
 void tesAddTaskTooLongDescription() {
 TaskService service = new TaskService();
 assertThrows(IllegalArgumentException.class,
 () -> service.addTask("ChanceTask", "check Chance for fleas 
and ticks and make sure everything else is checked tooooo"));

 }

//test addTask null

 @Test
 void testAddTaskNameNull() {
 TaskService service = new TaskService();
 assertThrows(IllegalArgumentException.class, () -> service.addTask(null, 
"check Chance for fleas and ticks"));
 }

 @Test
 void testAddTaskDescriptionNull() {
 TaskService service = new TaskService();
 assertThrows(IllegalArgumentException.class,
 () -> service.addTask("ChanceTask", null));
 }

 //test delete

 @Test
 void tsetDeleteTask() throws Exception {
 TaskService service = new TaskService();
 service.addTask("ChanceTask", "check Chance for fleas and ticks");
 assertEquals(1, service.getlistOfTask().size());
 service.deleteTask(service.getlistOfTask().get(0).getTaskId());
 assertEquals(0, service.getlistOfTask().size());

 }

 @Test

 void testDeleteTaskNotFound() throws Exception {
 TaskService service = new TaskService();
 service.addTask("ChanceTask", "check Chance for fleas and ticks");
 assertEquals(1, service.getlistOfTask().size());
 assertThrows(Exception.class, () -> service.deleteTask("123456789"));
 assertEquals(1, service.getlistOfTask().size());
 }

//test update

 @Test
 void testUpdateName() throws Exception {
 TaskService service = new TaskService();
 service.addTask("ChanceTask", "check Chance for fleas and ticks");
 service.updateName(service.getlistOfTask().get(0).getTaskId(), 

"ChanceTask");
 assertEquals("ChanceTask", service.getlistOfTask().get(0).getName());
 }

 @Test
 void testUpdateDescription() throws Exception {
 TaskService service = new TaskService();
 service.addTask("ChanceTask", "check Chance for fleas and ticks");
 service.updateDescription(service.getlistOfTask().get(0).getTaskId(),
 "check Chance for fleas and ticks");

 assertEquals("check Chance for fleas and ticks", 

service.getlistOfTask().get(0).getDescription());

 }

} //end class
